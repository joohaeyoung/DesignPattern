import java.util.Optional;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ShowImage extends Application {
	private String imageURL = "";
	@Override
	public void start(Stage primaryStage) throws Exception {
		TextInputDialog getURLDialog = new TextInputDialog();
		getURLDialog.setTitle("이미지 주소 입력창");
		getURLDialog.setHeaderText("웹 이미지 주소를 입력하여 주십시오.");
		Optional<String> userInput = getURLDialog.showAndWait();
		if(userInput.isPresent()){
			imageURL = userInput.get();
			System.out.println(imageURL);
		}
		
		Pane pane = new Pane();
		Image img = new Image(imageURL);
		ImageView iView = new ImageView(img);
		pane.getChildren().add(iView);
		
		primaryStage.setTitle("Virtual Proxy Pattern App");
		primaryStage.setScene(new Scene(pane));
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
