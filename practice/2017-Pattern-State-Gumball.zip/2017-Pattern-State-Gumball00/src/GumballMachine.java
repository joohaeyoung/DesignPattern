/**
 * State Driven Transition (상태 기반 전이)
 * @author 김상진
 *
 */
public class GumballMachine {
	public enum GumballState {SOLD_OUT, NO_COIN, HAS_COIN, SOLD};
	private GumballState currentState;
	private int count = 0;
	public GumballMachine(int numberGumballs) {
		count = numberGumballs;
 		if(count > 0) currentState = GumballState.NO_COIN;
 		else currentState = GumballState.SOLD_OUT;
	}	
	public void insertCoin(){	
		switch(currentState){
		case HAS_COIN:
			System.out.println("이미 동전이 있음");
			break;
		case NO_COIN:
			System.out.println("동전이 삽입되었음");
			currentState = GumballState.HAS_COIN;
			break;
		case SOLD:
			System.out.println("동전을 투입할 수 있는 단계가 아님");
			break;
		case SOLD_OUT:
			System.out.println("껌볼이 없어 판매가 중단됨");
			break;
		}

	}
	public void ejectCoin(){	
		switch(currentState){
		case HAS_COIN:
			System.out.println("취소되었음");
			currentState = GumballState.NO_COIN;
			break;
		case NO_COIN:
			System.out.println("반환할 동전 없음");
			currentState = GumballState.HAS_COIN;
			break;
		case SOLD:
			System.out.println("동전이 없음");
			break;
		case SOLD_OUT:
			System.out.println("껌볼이 없어 판매가 중단됨");
			break;
		}
	}
	public void turnCrank(){	
		switch(currentState){
		case HAS_COIN:
			System.out.println("손잡이를 돌렸음");
			currentState = GumballState.SOLD;
			break;
		case NO_COIN:
			System.out.println("동전이 없어 손잡이를 돌릻 수 없음");
			break;
		case SOLD:
			System.out.println("이미 손잡이를 돌렸음");
			break;
		case SOLD_OUT:
			System.out.println("껌볼이 없어 판매가 중단됨");
			break;
		}
		dispense();
	}
	public void dispense(){
		switch(currentState){
		case HAS_COIN:
			System.out.println("손잡이를 돌려야 껌볼이 나옴");
			break;
		case NO_COIN:
			System.out.println("동전을 투입해야 구입할 수 있음");
			break;
		case SOLD:
			System.out.println("껌볼이 나옴");
			if(count>0) --count;
			System.out.println(count);
			if(isEmpty()){
				System.out.println("껌볼이 더 이상 없습니다.");
				currentState = GumballState.SOLD_OUT;
			}
			else{			
				currentState = GumballState.NO_COIN;
			}
			break;
		case SOLD_OUT:
			System.out.println("껌볼이 없어 판매가 중단됨");
			break;
		}
	}
	public int getNumberOfGumballs(){
		return count;
	}
	public boolean isEmpty(){
		return (count==0);
	}
}
