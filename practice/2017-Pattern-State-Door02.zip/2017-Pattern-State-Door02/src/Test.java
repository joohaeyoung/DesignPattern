
public class Test {
	public static void main(String[] args){
		Door door = new Door();
        door.close();
        door.lock();
        door.open();
        door.unlock();
        door.open();
	}
}
