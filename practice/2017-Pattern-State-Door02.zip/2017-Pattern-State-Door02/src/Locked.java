
public class Locked implements DoorState {
	private Door door;
    public Locked(Door door){
        this.door = door;
    }
	@Override
	public void open() {
		//
	}

	@Override
	public void close() {
		//
	}

	@Override
	public void lock() {
		//
	}

	@Override
	public void unlock() {
		//
	}

}
