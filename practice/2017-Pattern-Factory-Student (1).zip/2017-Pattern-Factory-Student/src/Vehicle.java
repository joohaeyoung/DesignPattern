/**
* 객체지향개발론 및 실습 2017학년도 1학기 실습 4. Factory Method 패턴
* @author 김상진 (한국기술교육대학교 컴퓨터공학부)
* 모든 종류의 차량을 추상화할 수 있는 추상 Product 클래스
*/
public abstract class Vehicle {
	public enum Color {UNPAINTED, BLUE, BLACK, PERLWHITE, WHITE, SILVER, GRAY, RED};
	private Vehicle.Color color = Vehicle.Color.UNPAINTED;
	private String description;
	public Vehicle(){ 
	}
	public Vehicle(String description){
		this.description = description;
	}
	public void paint(Color color){
		this.color = color;
	}
	public abstract int cost();
	public String toString(){
		return String.format("%s, %s, %,d만원%n", description, color, cost());
	}
}
