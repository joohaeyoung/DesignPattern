/**
* 객체지향개발론 및 실습 2017학년도 1학기 실습 4. Factory Method 패턴
* @author 김상진 (한국기술교육대학교 컴퓨터공학부)
* 차량을 생산하는 Abstract Creator 클래스
*/
public abstract class VehicleFactory {
	public enum DrivingStyle {ECONOMICAL, MIDRANGE, LUXURY, POWERFUL};
	public final Vehicle build(DrivingStyle style, Vehicle.Color color){
		// 완성하시오.
		return null;
	}
	protected abstract Vehicle selectVehicle(DrivingStyle style);
}
